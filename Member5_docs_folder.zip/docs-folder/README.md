# Qveto Project Management & Team Collaboration SaaS

## Overview
A team project for managing organizations, workspaces, teams, projects, tasks, and collaboration.

## Project status
Initial README template. Confirm commands/configuration with the integration/backend team before treating them as verified.

## Requirements
- Git
- Node.js/npm if required by the current application
- Database supported by the project's Prisma configuration

## Setup
1. Clone the repository.
2. Install dependencies using the package manager and lockfile in the repository.
3. Configure environment variables using the team's approved example file. Do not commit secrets.
4. Run the documented database migration command.
5. Run the seed command if applicable.
6. Start the application using scripts defined in `package.json`.

## Documentation
- [Requirements](docs/requirements.md)
- [Permission Matrix](docs/permission-matrix.md)
- [User Journeys](docs/user-journeys.md)
- [Test Cases](docs/test-cases.md)
- [Bug List](docs/bug-list.md)

## Security
Backend routes must enforce authorization and organization-level data isolation. Do not rely on frontend visibility alone.
